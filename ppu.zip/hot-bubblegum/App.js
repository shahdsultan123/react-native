import React, { Component } from 'react';
import { Text, View, TextInput, Button, Alert, Image ,SafeAreaView, ScrollView  } from 'react-native';

class Parent extends Component {
  
  render() {
    return (
      <View style={{flex :1}} >
        
        <View style={{
          flex: 10,
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor:"darkorange",
      
      }}>
        
   <View style={{flex:"30%"}}>
      <Image style={{height:70, width:55}} source={require('./img/h.png')} />
    
       </View>
     
       <View style={{justifyContent: 'center'}} >
      <Text > جامعة بوليتكنك فلسطين </Text>
    
       </View>

      <View >
<Image style={{height:70 , width:55}} source={require('./img/logo.png')} />
    
       </View>
      </View>
     
     <View  style={{flex: 35}}>

      <Image style={{height:200 , width:400}} source={require('./img/pp.jpg')} />
    
       </View>
    
     <View style={{borderTopWidth:'1em' ,borderColor:"gray", flex:40 }}> 
     
     
     <View style={{flexDirection:'row' ,position: 'absolute', left: 0, right: 0, 
      justifyContent:'space-around',
      alignItems:'center'}}> 
     
     <View >  <Image style={{height:80 , width:90}} source={require('./img/d.jpg')} />
     <Text > شؤون الطلبة</Text>
    <Image style={{height:80 , width:90}} source={require('./img/b.png')} />
     <Text> </Text>
    </View>
     
     
     <View> <Image style={{height:80 , width:90}} source={require('./img/f.png')} />
     <Text>  علامات الطلاب </Text> 
    <Image style={{height:80 , width:90}} source={require('./img/a.png')} />
     <Text>موقع الكتروني</Text>
     </View>
     <View> <Image style={{height:80 , width:90}} source={require('./img/b.png')} />
     <Text> مباني الجامعة</Text> 
     <Image style={{height:80 , width:90}} source={require('./img/d.jpg')} />
     <Text> منح دراسية</Text>
     
     </View>
     
     </View>
     
     </View>
      
      <View  style={{flex: 10 ,flexDirection:'row'}}>
     
      <ScrollView  horizontal={true} 
  pagingEnabled={true}>
       <View style={{flexDirection:'row'}} >
       <Text style={{borderWidth:2, borderColor:'gray' ,fontSize:40 ,backgroundColor:"darkorange"}}>IS</Text>
       <Text style={{borderWidth:2, borderColor:'gray' ,fontSize:40 ,backgroundColor:"darkorange"}}>IT</Text>
       <Text style={{borderWidth:2, borderColor:'gray' ,fontSize:40 ,backgroundColor:"darkorange"}}>Cs</Text>
       <Text style={{borderWidth:2, borderColor:'gray' ,fontSize:40 ,backgroundColor:"darkorange"}}>CE</Text>
       <Text style={{borderWidth:2, borderColor:'gray' ,fontSize:40 ,backgroundColor:"darkorange"}}>Mis</Text>
        <Text style={{borderWidth:2, borderColor:'gray' ,fontSize:40 ,backgroundColor:"darkorange"}}>Acc</Text>
        <Text style={{borderWidth:2, borderColor:'gray' ,fontSize:40,backgroundColor:"darkorange"}}>Se</Text>
        <Text style={{borderWidth:2, borderColor:'gray' ,fontSize:40,backgroundColor:"darkorange"}}>Mis</Text>
       
       
       
       </View>
        
      </ScrollView>
    
    
      </View>
      </View>
    );
 
 
  }
}
export default Parent;